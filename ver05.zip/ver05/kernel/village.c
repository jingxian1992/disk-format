#include <linux/head.h>

unsigned int * pg_dir;
struct desc_struct * idt;
struct desc_struct * gdt;














