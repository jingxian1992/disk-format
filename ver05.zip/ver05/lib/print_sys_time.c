#include <sys_call.h>

extern _syscall0(int,print_sys_time)


