/home/shuilingling/C_SYS/bochs_gdb01/bin/bochs -f gdb.bxrc
