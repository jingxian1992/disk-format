#include <sys_call.h>

extern _syscall2(int,write_simple,const char *,buf,int,count)


