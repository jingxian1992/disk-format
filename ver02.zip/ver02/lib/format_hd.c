#include <sys_call.h>

extern _syscall1(int, format_hd, int, index)
