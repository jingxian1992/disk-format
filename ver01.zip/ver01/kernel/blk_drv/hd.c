#include <stdio.h>
#include <linux/sched.h>
#include <asm/system.h>
#include <asm/io.h>
#include <asm/segment.h>
#include <string.h>

#define MAJOR_NR 3
#include <linux/blk.h>

/* Max read/write errors/sector */
#define MAX_ERRORS	7
#define MAX_HD		2

static void recal_intr(void);
static void bad_rw_intr(void);
static void do_hd_request(void);

struct hd_i_struct
{
	int head,sect,cyl,wpcom,lzone,ctl;
};

struct hd_i_struct hd_info[MAX_HD];
static int NR_HD;
int hd_timeout;
void (* do_hd)(void);

struct hd_struct
{
	int start_sect;
	int nr_sects;
};

static struct hd_struct hd[5 * MAX_HD];
static int hd_sizes[5 * MAX_HD];
static int recalibrate;
static int reset;

static void SET_INTR(void (* x)(void))
{
	do_hd = x;
	hd_timeout = 200;
}

static int DEVICE_NR(int device)
{
	int res;
	res = MINOR(device) / 5;
	return res;
}

static inline void unlock_buffer(struct buffer_head * bh)
{
	if (!bh->b_lock)
		printk("harddisk: free buffer being unlocked\n");
	bh->b_lock=0;
	wake_up(&bh->b_wait);
}

static inline void end_request(int uptodate)
{
	if (CURRENT->bh) {
		CURRENT->bh->b_uptodate = uptodate;
		unlock_buffer(CURRENT->bh);
	}
	if (!uptodate) {
		printk("harddisk I/O error\n\r");
		printk("dev %04x, block %d\n\r",CURRENT->dev,
			CURRENT->bh->b_blocknr);
	}
	wake_up(&CURRENT->waiting);
	wake_up(&wait_for_request);
	CURRENT->dev = -1;
	CURRENT = CURRENT->next;
}
 
static void CLEAR_DEVICE_TIMEOUT(void)
{
	hd_timeout = 0;
}

static void CLEAR_DEVICE_INTR(void)
{
	do_hd = NULL;
}

static void port_read(int port, void * buf, int nr)
{
__asm__("cld;rep;insw"::"d" (port),"D" (buf),"c" (nr));
}

static void port_write(int port, void * buf, int nr)
{
__asm__("cld;rep;outsw"::"d" (port),"S" (buf),"c" (nr));
}

extern int sys_setup_first_disk(void)
{
	unsigned char * disk_buffer;
	struct partition * p;
	struct d_super_block * disk_super;
	int i, LBA_sector;
	
	disk_buffer = (unsigned char *)0x100000;
	LBA_sector = 0;
	
/*  boot block set  */
	memset(disk_buffer, 0, 1024);
	disk_buffer[510] = 0x55;
	disk_buffer[511] = 0xAA;
	p = (struct partition *)(disk_buffer + 0x1BE);
	p->boot_ind = 0;
	p->head = 0;
	p->sector = 1;
	p->cyl = 0;
	p->sys_ind = 0x80;
	p->end_head = 15;
	p->end_sector = 63;
	p->end_cyl = 13;
	p->start_sect = 0;
	p->nr_sects = 14 * 16 * 63 - 1;
	write_first_disk(LBA_sector, disk_buffer);
	LBA_sector += 2;
	
/*  super block set  */
	memset(disk_buffer, 0, 1024);
	disk_super = (struct d_super_block *)disk_buffer;
	disk_super->s_ninodes = 1024;
	disk_super->s_nzones = 7 * 16 * 63 - 36;
	disk_super->s_imap_blocks = 1;
	disk_super->s_zmap_blocks = 1;
	disk_super->s_firstdatazone = 36;
	disk_super->s_log_zone_size = 0;
	disk_super->s_max_size = 512*7 + 512*512 + 512*512*512;
	disk_super->s_magic = 0x137F;
	write_first_disk(LBA_sector, disk_buffer);
	LBA_sector +=2;
	
/*  inode map set  */
	memset(disk_buffer, 0, 1024);
	*disk_buffer = 1;
	*(disk_buffer + (1024/8)) = 0xFE;
	memset(disk_buffer + (1024/8) + 1, 0xFF, 1024 - 1024/8 -1);
	write_first_disk(LBA_sector, disk_buffer);
	LBA_sector += 2;
	
/*  logic block zone map set  */
	memset(disk_buffer, 0, 1024);
	*disk_buffer = 1;
	*(disk_buffer + (7021/8)) = 0xC0;
	memset(disk_buffer + (7021/8) + 1, 0xFF, 1024 - 7021/8 - 1);
	write_first_disk(LBA_sector, disk_buffer);
	LBA_sector += 2;
	
/*  inode table set  */
	memset(disk_buffer, 0, 1024);
	for (i = 0; i < 32; i++)
	{
		write_first_disk(LBA_sector, disk_buffer);
		LBA_sector += 2;
	}
	
	printk("\tsetup first disk is done.\n");
}

extern int sys_setup_second_disk(void)
{
	unsigned char * disk_buffer;
	struct partition * p;
	struct d_super_block * disk_super;
	int i, LBA_sector;
	
	disk_buffer = (unsigned char *)0x100000;
	LBA_sector = 0;
	
/*  boot block set  */
	memset(disk_buffer, 0, 1024);
	disk_buffer[510] = 0x55;
	disk_buffer[511] = 0xAA;
	p = (struct partition *)(disk_buffer + 0x1BE);
	p->boot_ind = 0;
	p->head = 0;
	p->sector = 1;
	p->cyl = 0;
	p->sys_ind = 0x80;
	p->end_head = 15;
	p->end_sector = 63;
	p->end_cyl = 13;
	p->start_sect = 0;
	p->nr_sects = 14 * 16 * 63 - 1;
	write_second_disk(LBA_sector, disk_buffer);
	LBA_sector += 2;
	
/*  super block set  */
	memset(disk_buffer, 0, 1024);
	disk_super = (struct d_super_block *)disk_buffer;
	disk_super->s_ninodes = 1024;
	disk_super->s_nzones = 7 * 16 * 63 - 36;
	disk_super->s_imap_blocks = 1;
	disk_super->s_zmap_blocks = 1;
	disk_super->s_firstdatazone = 36;
	disk_super->s_log_zone_size = 0;
	disk_super->s_max_size = 512*7 + 512*512 + 512*512*512;
	disk_super->s_magic = 0x137F;
	write_second_disk(LBA_sector, disk_buffer);
	LBA_sector +=2;
	
/*  inode map set  */
	memset(disk_buffer, 0, 1024);
	*disk_buffer = 1;
	*(disk_buffer + (1024/8)) = 0xFE;
	memset(disk_buffer + (1024/8) + 1, 0xFF, 1024 - 1024/8 -1);
	write_second_disk(LBA_sector, disk_buffer);
	LBA_sector += 2;
	
/*  logic block zone map set  */
	memset(disk_buffer, 0, 1024);
	*disk_buffer = 1;
	*(disk_buffer + (7021/8)) = 0xC0;
	memset(disk_buffer + (7021/8) + 1, 0xFF, 1024 - 7021/8 - 1);
	write_second_disk(LBA_sector, disk_buffer);
	LBA_sector += 2;
	
/*  inode table set  */
	memset(disk_buffer, 0, 1024);
	for (i = 0; i < 32; i++)
	{
		write_second_disk(LBA_sector, disk_buffer);
		LBA_sector += 2;
	}
	
	printk("\tsetup second disk is done.\n");
}




static int controller_ready(void)
{
	int retries = 100000;

	while (--retries && (inb_p(HD_STATUS)&0xc0)!=0x40);
	return (retries);
}

static int win_result(void)
{
	int i=inb_p(HD_STATUS);

	if ((i & (BUSY_STAT | READY_STAT | WRERR_STAT | SEEK_STAT | ERR_STAT))
		== (READY_STAT | SEEK_STAT))
		return(0); /* ok */
	if (i&1) i=inb(HD_ERROR);
	return (1);
}

static void hd_out(unsigned int drive,unsigned int nsect,unsigned int sect,
		unsigned int head,unsigned int cyl,unsigned int cmd,
		void (*intr_addr)(void))
{
	register int port asm("dx");

	if (drive>1 || head>15)
		panic("Trying to write bad sector");
	if (!controller_ready())
		panic("HD controller not ready");
	SET_INTR(intr_addr);
	outb_p(hd_info[drive].ctl,HD_CMD);
	port=HD_DATA;
	outb_p(hd_info[drive].wpcom>>2,++port);
	outb_p(nsect,++port);
	outb_p(sect,++port);
	outb_p(cyl,++port);
	outb_p(cyl>>8,++port);
	outb_p(0xA0|(drive<<4)|head,++port);
	outb(cmd,++port);
}

static int drive_busy(void)
{
	unsigned int i;
	unsigned char c;

	for (i = 0; i < 50000; i++) {
		c = inb_p(HD_STATUS);
		c &= (BUSY_STAT | READY_STAT | SEEK_STAT);
		if (c == (READY_STAT | SEEK_STAT))
			return 0;
	}
	printk("HD controller times out\n\r");
	return(1);
}

static void reset_controller(void)
{
	int	i;

	outb(4,HD_CMD);
	for(i = 0; i < 1000; i++) nop();
	outb(hd_info[0].ctl & 0x0f ,HD_CMD);
	if (drive_busy())
		printk("HD-controller still busy\n\r");
	if ((i = inb(HD_ERROR)) != 1)
		printk("HD-controller reset failed: %02x\n\r",i);
}

static void reset_hd(void)
{
	static int i;

repeat:
	if (reset) {
		reset = 0;
		i = -1;
		reset_controller();
	} else if (win_result()) {
		bad_rw_intr();
		if (reset)
			goto repeat;
	}
	i++;
	if (i < NR_HD) {
		hd_out(i,hd_info[i].sect,hd_info[i].sect,hd_info[i].head-1,
			hd_info[i].cyl,WIN_SPECIFY,&reset_hd);
	} else
		do_hd_request();
}

void unexpected_hd_interrupt(void)
{
	printk("Unexpected HD interrupt\n\r");
	reset = 1;
	do_hd_request();
}

static void bad_rw_intr(void)
{
	if (++CURRENT->errors >= MAX_ERRORS)
		end_request(0);
	if (CURRENT->errors > MAX_ERRORS/2)
		reset = 1;
}

static void read_intr(void)
{
	if (win_result()) {
		bad_rw_intr();
		do_hd_request();
		return;
	}
	port_read(HD_DATA,CURRENT->buffer,256);
	CURRENT->errors = 0;
	CURRENT->buffer += 512;
	CURRENT->sector++;
	if (--CURRENT->nr_sectors) {
		SET_INTR(&read_intr);
		return;
	}
	end_request(1);
	do_hd_request();
}

static void write_intr(void)
{
	if (win_result()) {
		bad_rw_intr();
		do_hd_request();
		return;
	}
	if (--CURRENT->nr_sectors) {
		CURRENT->sector++;
		CURRENT->buffer += 512;
		SET_INTR(&write_intr);
		port_write(HD_DATA,CURRENT->buffer,256);
		return;
	}
	end_request(1);
	do_hd_request();
}

static void recal_intr(void)
{
	if (win_result())
		bad_rw_intr();
	do_hd_request();
}

void hd_times_out(void)
{
	if (!CURRENT)
		return;
	printk("HD timeout");
	if (++CURRENT->errors >= MAX_ERRORS)
		end_request(0);
	SET_INTR(NULL);
	reset = 1;
	do_hd_request();
}

void do_hd_request(void)
{
	int i,r;
	unsigned int block,dev;
	unsigned int sec,head,cyl;
	unsigned int nsect;

repeat:
	if (!CURRENT) {
		CLEAR_DEVICE_INTR();
		CLEAR_DEVICE_TIMEOUT();
		return;
	}
	if (MAJOR(CURRENT->dev) != MAJOR_NR)
		panic("harddisk: request list destroyed");
	if (CURRENT->bh) {
		if (!CURRENT->bh->b_lock)
			panic("harddisk: block not locked");
	}

	dev = MINOR(CURRENT->dev);
	block = CURRENT->sector;
	if (dev >= 5*NR_HD || block+2 > hd[dev].nr_sects) {
		end_request(0);
		goto repeat;
	}
	block += hd[dev].start_sect;
	dev /= 5;
	__asm__("divl %4":"=a" (block),"=d" (sec):"0" (block),"1" (0),
		"r" (hd_info[dev].sect));
	__asm__("divl %4":"=a" (cyl),"=d" (head):"0" (block),"1" (0),
		"r" (hd_info[dev].head));
	sec++;
	nsect = CURRENT->nr_sectors;
	if (reset) {
		recalibrate = 1;
		reset_hd();
		return;
	}
	if (recalibrate) {
		recalibrate = 0;
		hd_out(dev,hd_info[CURRENT_DEV].sect,0,0,0,
			WIN_RESTORE,&recal_intr);
		return;
	}	
	if (CURRENT->cmd == WRITE) {
		hd_out(dev,nsect,sec,head,cyl,WIN_WRITE,&write_intr);
		for(i=0 ; i<10000 && !(r=inb_p(HD_STATUS)&DRQ_STAT) ; i++)
			/* nothing */ ;
		if (!r) {
			bad_rw_intr();
			goto repeat;
		}
		port_write(HD_DATA,CURRENT->buffer,256);
	} else if (CURRENT->cmd == READ) {
		hd_out(dev,nsect,sec,head,cyl,WIN_READ,&read_intr);
	} else
		panic("unknown hd-command");
}

void hd_init(void)
{
	int i;
	for (i = 0; i < MAX_HD; i++)
	{
		hd_info[i].head = 0;
		hd_info[i].sect = 0;
		hd_info[i].cyl = 0;
		hd_info[i].wpcom = 0;
		hd_info[i].lzone = 0;
		hd_info[i].ctl = 0;
	}
	
	NR_HD = 0;
	
	for (i = 0; i < (5 * MAX_HD); i++)
	{
		hd[i].start_sect = 0;
		hd[i].nr_sects = 0;
	}
	
	for (i = 0; i < (5 * MAX_HD); i++)
	{
		hd_sizes[i] = 0;
	}

	recalibrate = 0;
	reset = 0;	
	hd_timeout = 0;
	do_hd = NULL;
	recalibrate = 0;
	reset = 0;

	blk_dev[MAJOR_NR].request_fn = do_hd_request;
//	set_intr_gate(0x2E,&hd_interrupt);
//	outb_p(inb_p(0x21)&0xfb,0x21);
//	outb(inb_p(0xA1)&0xbf,0xA1);
}



void read_first_disk_base(unsigned int sector_num_lba, unsigned short * buffer)
{
	unsigned short port;
	unsigned char data, status_info;
	
	port = 0x1f2;
	data = 1;
	outb_p(data, port++);  // 向0x1F2写入本次操作的扇区数
	
	data = sector_num_lba & 0xFF;
	outb_p(data, port++);   // 向0x1F3写入扇区号低8位
	
	data = (sector_num_lba >> 8) & 0xFF;
	outb_p(data, port++);   // 向0x1F4写入扇区号的位8……位15
	
	data = (sector_num_lba >> 16) & 0xFF;
	outb_p(data, port++);   // 向0x1F5写入扇区号的位16……位23
	
	data = (sector_num_lba >> 24) & 0x0F;    // 扇区号的位24……位27放在data的低4位
	data |= 0xE0;     // data的高4位，设置为 0B1110，表示的是LBA操作方式。
	outb_p(data, port++);    // 将组建好的data值发送到端口0x1F6里面。
	
	data = 0x20;
	outb_p(data, port);   // 向)x1f7写入0x20命令。0x30表示【可重试读扇区】
	
	do
	{
		status_info = inb_p(port) & 0x88;
	} while (status_info != 0x08);
		
	port = 0x1F0;
	port_read(port, buffer, 256);
}

void read_second_disk_base(unsigned int sector_num_lba, unsigned short * buffer)
{
	unsigned short port;
	unsigned char data, status_info;
	
	port = 0x1f2;
	data = 1;
	outb_p(data, port++);  // 向0x1F2写入本次操作的扇区数
	
	data = sector_num_lba & 0xFF;
	outb_p(data, port++);   // 向0x1F3写入扇区号低8位
	
	data = (sector_num_lba >> 8) & 0xFF;
	outb_p(data, port++);   // 向0x1F4写入扇区号的位8……位15
	
	data = (sector_num_lba >> 16) & 0xFF;
	outb_p(data, port++);   // 向0x1F5写入扇区号的位16……位23
	
	data = (sector_num_lba >> 24) & 0x0F;    // 扇区号的位24……位27放在data的低4位
	data |= 0xF0;     // data的高4位，设置为 0B1111，表示的是LBA操作方式。
	outb_p(data, port++);    // 将组建好的data值发送到端口0x1F6里面。
	
	data = 0x20;
	outb_p(data, port);   // 向)x1f7写入0x20命令。0x30表示【可重试读扇区】
	
	do
	{
		status_info = inb_p(port) & 0x88;
	} while (status_info != 0x08);
		
	port = 0x1F0;
	port_read(port, buffer, 256);
}

void write_first_disk_base(unsigned int sector_num_lba, unsigned short * buffer)
{
	unsigned short port, data_info;
	unsigned char data, status_info;
	int i;
	
	port = 0x1f2;
	data = 1;
	outb_p(data, port++);  // 向0x1F2写入本次操作的扇区数
	
	data = sector_num_lba & 0xFF;
	outb_p(data, port++);   // 向0x1F3写入扇区号低8位
	
	data = (sector_num_lba >> 8) & 0xFF;
	outb_p(data, port++);   // 向0x1F4写入扇区号的位8……位15
	
	data = (sector_num_lba >> 16) & 0xFF;
	outb_p(data, port++);   // 向0x1F5写入扇区号的位16……位23
	
	data = (sector_num_lba >> 24) & 0x0F;    // 扇区号的位24……位27放在data的低4位
	data |= 0xE0;     // data的高4位，设置为 0B1110，表示的是LBA操作方式。
	outb_p(data, port++);    // 将组建好的data值发送到端口0x1F6里面。
	
	data = 0x30;
	outb_p(data, port);   // 向)x1f7写入0x30命令。0x30表示【可重试写扇区】
	
	for (i = 0; i < 10000; i++)
	{
		;
	}
		
	port = 0x1F0;
	port_write(port, buffer, 256);
	
	for (i = 0; i < 10000; i++)
	{
		;
	}

	port = 0x1F7;
	do
	{
		status_info = inb_p(port);
		status_info &= 0x80;
	}while (status_info != 0x00);
}

void write_second_disk_base(unsigned int sector_num_lba, unsigned short * buffer)
{
	unsigned short port, data_info;
	unsigned char data, status_info;
	int i;
	
	port = 0x1f2;
	data = 1;
	outb_p(data, port++);  // 向0x1F2写入本次操作的扇区数
	
	data = sector_num_lba & 0xFF;
	outb_p(data, port++);   // 向0x1F3写入扇区号低8位
	
	data = (sector_num_lba >> 8) & 0xFF;
	outb_p(data, port++);   // 向0x1F4写入扇区号的位8……位15
	
	data = (sector_num_lba >> 16) & 0xFF;
	outb_p(data, port++);   // 向0x1F5写入扇区号的位16……位23
	
	data = (sector_num_lba >> 24) & 0x0F;    // 扇区号的位24……位27放在data的低4位
	data |= 0xF0;     // data的高4位，设置为 0B1111，表示的是LBA操作方式。
	outb_p(data, port++);    // 将组建好的data值发送到端口0x1F6里面。
	
	data = 0x30;
	outb_p(data, port);   // 向)x1f7写入0x30命令。0x30表示【可重试写扇区】
	
	for (i = 0; i < 10000; i++)
	{
		;
	}
		
	port = 0x1F0;
	port_write(port, buffer, 256);
	
	for (i = 0; i < 10000; i++)
	{
		;
	}

	port = 0x1F7;
	do
	{
		status_info = inb_p(port);
		status_info &= 0x80;
	}while (status_info != 0x00);
}

void read_first_disk(unsigned int sector_num_lba, unsigned short * buffer)
{
	read_first_disk_base(sector_num_lba, buffer);
	
	sector_num_lba++;
	buffer += 256;
	
	read_first_disk_base(sector_num_lba, buffer);
}

void read_second_disk(unsigned int sector_num_lba, unsigned short * buffer)
{
	read_second_disk_base(sector_num_lba, buffer);
	
	sector_num_lba++;
	buffer += 256;
	
	read_second_disk_base(sector_num_lba, buffer);
}

void write_first_disk(unsigned int sector_num_lba, unsigned short * buffer)
{
	write_first_disk_base(sector_num_lba, buffer);
	
	sector_num_lba++;
	buffer += 256;
	
	write_first_disk_base(sector_num_lba, buffer);
}

void write_second_disk(unsigned int sector_num_lba, unsigned short * buffer)
{
	write_second_disk_base(sector_num_lba, buffer);
	
	sector_num_lba++;
	buffer += 256;
	
	write_second_disk_base(sector_num_lba, buffer);
}

