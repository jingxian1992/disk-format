#include <sys_call.h>

extern _syscall0(int, setup_first_disk)
extern _syscall0(int, setup_second_disk)
